import { Injectable } from '@angular/core';

@Injectable()

export class AuthService {

  public authToken: string;

  constructor() { }

}
